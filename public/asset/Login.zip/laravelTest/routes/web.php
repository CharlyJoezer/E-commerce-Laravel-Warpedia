<?php

use Faker\Core\Blood;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [BlogController::class, 'home']);
Route::get('about', [BlogController::class, 'about']);
Route::get('contact', [BlogController::class, 'contact']);
Route::get('data', [BlogController::class, 'data']);
Route::post('rekam/{proses}', [BlogController::class, 'proses']);

Route::get('dasboard', [HomeController::class, 'index'])->name('dasboard')->middleware('auth');
Route::get('login', [LoginController::class, 'index'])->name('login')->middleware('guest');
Route::post('actionlogin', [LoginController::class, 'actionlogin'])->name('actionlogin');
Route::get('logout', [LoginController::class, 'logout'])->name('logout');