<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index(){
        return view('login', [
            'title' => 'Form login'
        ]);
    }

    public function actionlogin(Request $request){
        $data = [
            'email'     => $request->input('email'),
            'password'  => $request->input('password')
        ];

        if(Auth::attempt($data)){
            return redirect('dasboard');
        } else {
            $request->session()->flash('error', 'Email atau Password salah');
            return redirect('/login');
        }
    }

   public function logout(){
        Auth::logout();    
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->back();
    }
}
