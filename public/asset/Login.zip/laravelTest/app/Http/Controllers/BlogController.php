<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function home(){
        return view('home', [
            "title" => "Home Page"
        ]);
    }
    public function about(){
        return view('about', [
            "title" => "About Page"
        ]);
    }
    public function contact(){
        return view('contact', [
            "title" => "Contact Page"
        ]);
    }
    public function data(){
        return view('dataCovid', [
            "title" => "Covid Data Record"
        ]);
    }
    public function proses(Request $request){
        $nama = $request->nama;
        $alamat = $request->alamat;
        return view('rekamData', [
            "title" => "Covid Data Record",
            'nama'  => $nama,
            'alamat' => $alamat
        ]);
    }
}
