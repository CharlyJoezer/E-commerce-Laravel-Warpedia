

<?php $__env->startSection('judul', 'Covid Data Record'); ?>

<?php $__env->startSection('konten'); ?>    
<h3>Data diri saat pandemi COvid-19</h3>
    <table>
        <tr>
            <td>Nama</td><td>:</td>
            <td><?php echo e($nama); ?></td>
        </tr>
        <tr>
            <td>Alamat</td><td>:</td>
            <td><?php echo e($alamat); ?></td>
        </tr>
        <tr>
            <td><button><a href="/data">Kembali</a></button></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/rekamData.blade.php ENDPATH**/ ?>