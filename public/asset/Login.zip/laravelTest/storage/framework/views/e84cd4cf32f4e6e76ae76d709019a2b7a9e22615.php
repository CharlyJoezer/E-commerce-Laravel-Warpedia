

<?php $__env->startSection('judul', 'About Page'); ?>

<?php $__env->startSection('konten'); ?>    
<h2>About me</h2>
    <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident voluptate, eaque a minima quisquam voluptatem.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/about.blade.php ENDPATH**/ ?>