<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
</head>
<body>
    <header>
        <h2>Belajar Framework Laravel 8</h2>
        <nav>
            <a href="/">Home</a>|
            <a href="/about">About</a>|
            <a href="/contact">Contact</a>|
            <a href="/data">Rekam data Covid-19</a>|
            <a href="/login">Login</a>
        </nav>
    </header>
    <br/><br/><br/>
    
    <h3><?php echo $__env->yieldContent('judul'); ?></h3>

    
    <?php echo $__env->yieldContent('konten'); ?>
    <br/><br/><br/>

    <footer>
        <p>Copyright &copy; 2022 XII RPL</p>
    </footer>
</body>
</html><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/layout/master.blade.php ENDPATH**/ ?>