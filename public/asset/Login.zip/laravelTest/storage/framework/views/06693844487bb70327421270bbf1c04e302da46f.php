

<?php $__env->startSection('judul', 'Silahkan Login'); ?>

<?php $__env->startSection('konten'); ?>    
<h3>Form Login</h3>

<?php if(session('error')): ?>
    <b>Maaf </b> <?php echo e(session('error')); ?>

<?php endif; ?>
<form action="/actionlogin" method="POST">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Email</td><td>:</td>
            <td><input type="email" name="email" autocomplete="off" autofocus></td>
        </tr>
        <tr>
            <td>Password</td><td>:</td>
            <td><input type="password" name="password" autocomplete="off"></td>
        </tr>
        <tr>
            <td><button type="submit">Login</button></td>
        </tr>
    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/login.blade.php ENDPATH**/ ?>