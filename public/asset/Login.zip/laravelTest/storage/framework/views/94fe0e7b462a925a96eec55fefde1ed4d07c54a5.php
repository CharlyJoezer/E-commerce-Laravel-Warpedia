

<?php $__env->startSection('judul', 'Contact Page'); ?>

<?php $__env->startSection('konten'); ?>    
<h2>Contact</h2>
<table cellpadding="2" cellspacing="0"> 
    <tr>
        <td>Nama</td><td>:</td>
        <td>Suyanto</td>
    </tr>
    <tr>
        <td>Alamat</td><td>:</td>
        <td>Jl. S.Parman no.14 Gn.Guntur</td>
    </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/contact.blade.php ENDPATH**/ ?>