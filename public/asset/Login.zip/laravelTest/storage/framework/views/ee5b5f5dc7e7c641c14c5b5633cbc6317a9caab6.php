

<?php $__env->startSection('judul', 'Administrator'); ?>

<?php $__env->startSection('konten'); ?>    
<p>
    <h4>Selamat Datang <b><?php echo e(Auth::user()->name); ?></b>, Anda Login sebagai <b><?php echo e(Auth::user()->role); ?></b>.</h4>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layoutadmin.masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/admin/index.blade.php ENDPATH**/ ?>