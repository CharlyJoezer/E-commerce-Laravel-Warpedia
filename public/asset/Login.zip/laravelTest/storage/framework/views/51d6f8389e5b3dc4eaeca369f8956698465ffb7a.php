

<?php $__env->startSection('judul', 'Covid Data Record'); ?>

<?php $__env->startSection('konten'); ?>    
<h3>form Input Data Perekaman Covid-19</h3>
<form action="rekam/proses" method="POST">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Nama</td><td>:</td>
            <td><input type="text" name="nama" autocomplete="off" autofocus></td>
        </tr>
        <tr>
            <td>Alamat</td><td>:</td>
            <td><input type="text" name="alamat" autocomplete="off"></td>
        </tr>
        <tr>
            <td><button type="submit">Kirim data</button></td>
        </tr>
    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/dataCovid.blade.php ENDPATH**/ ?>