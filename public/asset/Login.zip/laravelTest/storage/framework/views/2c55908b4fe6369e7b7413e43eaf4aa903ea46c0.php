

<?php $__env->startSection('judul', 'Home Page'); ?>

<?php $__env->startSection('konten'); ?>    
<p>
    <h2>Selamat Datang</h2>
    <p>
        Ini adalah halaman utama
    </p>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M Andhi Rohmat B\Desktop\laravel\laravelTest\resources\views/home.blade.php ENDPATH**/ ?>