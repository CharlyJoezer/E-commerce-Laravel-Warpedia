<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $title }}</title>
</head>
<body>
    <header>
        <h2>Belajar Framework Laravel 8</h2>
        <nav>
            <a href="/dasboard">Home</a>|
            <a href="/logout">Logout</a>
        </nav>
    </header>
    <br/><br/><br/>
    {{-- Judul Halaman --}}
    <h3>@yield('judul')</h3>

    {{-- Konten Halaman --}}
    @yield('konten')
    <br/><br/><br/>

    <footer>
        <p>Copyright &copy; 2022 XII RPL</p>
    </footer>
</body>
</html>