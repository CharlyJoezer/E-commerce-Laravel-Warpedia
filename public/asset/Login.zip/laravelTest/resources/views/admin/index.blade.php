@extends('admin.layoutadmin.masteradmin')

@section('judul', 'Administrator')

@section('konten')    
<p>
    <h4>Selamat Datang <b>{{Auth::user()->name}}</b>, Anda Login sebagai <b>{{Auth::user()->role}}</b>.</h4>
</p>
@endsection