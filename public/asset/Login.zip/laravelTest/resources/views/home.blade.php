@extends('layout.master')

@section('judul', 'Home Page')

@section('konten')    
<p>
    <h2>Selamat Datang</h2>
    <p>
        Ini adalah halaman utama
    </p>
</p>
@endsection