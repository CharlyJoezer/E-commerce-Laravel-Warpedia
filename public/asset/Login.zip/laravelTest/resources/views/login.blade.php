@extends('layout.master')

@section('judul', 'Silahkan Login')

@section('konten')    
<h3>Form Login</h3>
{{-- Session error --}}
@if (session('error'))
    <b>Maaf </b> {{ session('error') }}
@endif
<form action="/actionlogin" method="POST">
    @csrf
    <table>
        <tr>
            <td>Email</td><td>:</td>
            <td><input type="email" name="email" autocomplete="off" autofocus></td>
        </tr>
        <tr>
            <td>Password</td><td>:</td>
            <td><input type="password" name="password" autocomplete="off"></td>
        </tr>
        <tr>
            <td><button type="submit">Login</button></td>
        </tr>
    </table>
</form>
@endsection