@extends('layout.master')

@section('judul', 'About Page')

@section('konten')    
<h2>About me</h2>
    <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident voluptate, eaque a minima quisquam voluptatem.
    </p>
@endsection