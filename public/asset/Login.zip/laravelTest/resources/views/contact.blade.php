@extends('layout.master')

@section('judul', 'Contact Page')

@section('konten')    
<h2>Contact</h2>
<table cellpadding="2" cellspacing="0"> 
    <tr>
        <td>Nama</td><td>:</td>
        <td>Suyanto</td>
    </tr>
    <tr>
        <td>Alamat</td><td>:</td>
        <td>Jl. S.Parman no.14 Gn.Guntur</td>
    </tr>
</table>
@endsection