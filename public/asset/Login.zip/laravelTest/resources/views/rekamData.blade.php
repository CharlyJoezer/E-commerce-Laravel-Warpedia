@extends('layout.master')

@section('judul', 'Covid Data Record')

@section('konten')    
<h3>Data diri saat pandemi COvid-19</h3>
    <table>
        <tr>
            <td>Nama</td><td>:</td>
            <td>{{ $nama }}</td>
        </tr>
        <tr>
            <td>Alamat</td><td>:</td>
            <td>{{ $alamat }}</td>
        </tr>
        <tr>
            <td><button><a href="/data">Kembali</a></button></td>
        </tr>
    </table>
@endsection