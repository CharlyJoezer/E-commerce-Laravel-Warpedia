@extends('layout.master')

@section('judul', 'Covid Data Record')

@section('konten')    
<h3>form Input Data Perekaman Covid-19</h3>
<form action="rekam/proses" method="POST">
    @csrf
    <table>
        <tr>
            <td>Nama</td><td>:</td>
            <td><input type="text" name="nama" autocomplete="off" autofocus></td>
        </tr>
        <tr>
            <td>Alamat</td><td>:</td>
            <td><input type="text" name="alamat" autocomplete="off"></td>
        </tr>
        <tr>
            <td><button type="submit">Kirim data</button></td>
        </tr>
    </table>
</form>
@endsection